"""
AitherNode Standalone Server
=============================

Lightweight FastAPI server that provides:
1. Chat proxy (Genesis or Ollama fallback)
2. MCP tools (filesystem, git, code search — local only)
3. Health/status endpoint
4. Cloud registration (optional)

This is the STANDALONE version — runs without Docker, without Genesis.
When Genesis is available, it proxies. When not, it falls back to local.
"""

import os
import logging
from typing import Any, Dict, Optional
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from aithernode.sync import get_sync_client, API_KEY as SYNC_API_KEY
from aithernode.license import get_license_manager

logger = logging.getLogger("aithernode")

# ── Configuration ───────────────────────────────────────────────────

GENESIS_URL = os.environ.get("AITHER_URL", "http://localhost:8001")
VLLM_URL = os.environ.get("AITHER_VLLM_URL", os.environ.get("VLLM_URL", "http://localhost:8120"))
OLLAMA_URL = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
ELYSIUM_URL = os.environ.get("AITHER_CLOUD_URL", "https://mcp.aitherium.com")
NODE_PORT = int(os.environ.get("AITHERNODE_PORT", "8090"))
API_KEY = os.environ.get("AITHER_API_KEY", "")
MODE = os.environ.get("AITHERNODE_MODE", "auto")  # auto, local, cloud, standalone
VLLM_MODEL = os.environ.get("VLLM_SERVED_MODEL", os.environ.get("AITHER_DEFAULT_MODEL", ""))


# ── Backend detection ───────────────────────────────────────────────

async def _probe(url: str) -> bool:
    """Quick health probe."""
    try:
        import httpx
        async with httpx.AsyncClient(timeout=3.0) as c:
            r = await c.get(f"{url.rstrip('/')}/health")
            return r.status_code == 200
    except Exception:
        return False


class BackendState:
    """Tracks which backends are available."""
    genesis: bool = False
    vllm: bool = False
    ollama: bool = False
    cloud: bool = False
    mode: str = "standalone"

    async def refresh(self):
        self.genesis = await _probe(GENESIS_URL)
        self.vllm = await _probe(VLLM_URL)
        self.ollama = await _probe(OLLAMA_URL)
        if API_KEY:
            self.cloud = await _probe(ELYSIUM_URL)

        if MODE == "cloud":
            self.mode = "cloud" if self.cloud else "standalone"
        elif MODE == "local":
            if self.genesis:
                self.mode = "genesis"
            elif self.vllm:
                self.mode = "vllm"
            elif self.ollama:
                self.mode = "ollama"
            else:
                self.mode = "standalone"
        else:  # auto — prefer genesis > vllm > cloud > ollama
            if self.genesis:
                self.mode = "genesis"
            elif self.vllm:
                self.mode = "vllm"
            elif self.cloud and API_KEY:
                self.mode = "cloud"
            elif self.ollama:
                self.mode = "ollama"
            else:
                self.mode = "standalone"


_state = BackendState()


# ── Lifespan ────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    await _state.refresh()
    logger.info(f"AitherNode started -- mode: {_state.mode}")
    logger.info(f"  Genesis: {'UP' if _state.genesis else 'DOWN'}")
    logger.info(f"  vLLM:    {'UP' if _state.vllm else 'DOWN'} ({VLLM_URL})")
    logger.info(f"  Ollama:  {'UP' if _state.ollama else 'DOWN'}")
    logger.info(f"  Cloud:   {'UP' if _state.cloud else 'DOWN'}")

    # Validate subscription license
    lic = get_license_manager()
    try:
        lic_result = await lic.validate()
        logger.info("  License: %s (plan=%s)", lic_result.get("status"), lic_result.get("plan"))
    except Exception as e:
        logger.warning("  License: FAILED (%s)", e)

    # Start workspace sync if API key is configured
    sync = get_sync_client()
    if SYNC_API_KEY:
        try:
            await sync.start_background_sync()
            logger.info("  Sync:    ACTIVE (tenant: %s)", sync.workspace.tenant_id or "pending")
        except Exception as e:
            logger.warning("  Sync:    FAILED (%s)", e)
    else:
        logger.info("  Sync:    DISABLED (no API key)")

    yield

    # Stop background sync
    await sync.stop()
    logger.info("AitherNode stopped")


# ── App ─────────────────────────────────────────────────────────────

app = FastAPI(
    title="AitherNode",
    description="Lightweight local gateway for AitherOS",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Models ──────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    message: str
    conversation_id: Optional[str] = None
    model: Optional[str] = None
    stream: bool = False


class NodeStatus(BaseModel):
    status: str = "ok"
    mode: str = ""
    genesis: bool = False
    vllm: bool = False
    ollama: bool = False
    cloud: bool = False
    version: str = "0.1.0"
    port: int = NODE_PORT


# ── Endpoints ───────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {"status": "healthy", "service": "AitherNode", "mode": _state.mode}


@app.get("/status")
async def status():
    await _state.refresh()
    return NodeStatus(
        mode=_state.mode,
        genesis=_state.genesis,
        vllm=_state.vllm,
        ollama=_state.ollama,
        cloud=_state.cloud,
    )


@app.post("/chat")
async def chat(req: ChatRequest):
    """Proxy chat to best available backend."""
    import httpx

    if _state.mode == "genesis":
        async with httpx.AsyncClient(timeout=120.0) as c:
            headers = {}
            if API_KEY:
                headers["Authorization"] = f"Bearer {API_KEY}"
            r = await c.post(f"{GENESIS_URL}/chat", json=req.model_dump(), headers=headers)
            return r.json()

    elif _state.mode == "vllm":
        # Direct vLLM — OpenAI-compatible API (no Genesis pipeline)
        async with httpx.AsyncClient(timeout=120.0) as c:
            model = req.model or VLLM_MODEL or "default"
            payload = {
                "model": model,
                "messages": [{"role": "user", "content": req.message}],
                "max_tokens": 4096,
                "stream": False,
            }
            r = await c.post(f"{VLLM_URL}/v1/chat/completions", json=payload)
            data = r.json()
            content = ""
            if data.get("choices"):
                content = data["choices"][0].get("message", {}).get("content", "")
            usage = data.get("usage", {})
            return {
                "response": content,
                "model_used": data.get("model", model),
                "tokens": {
                    "prompt_tokens": usage.get("prompt_tokens", 0),
                    "completion_tokens": usage.get("completion_tokens", 0),
                    "total_tokens": usage.get("total_tokens", 0),
                },
                "metadata": {"elapsed_ms": 0, "effort_level": 3, "via": "vllm-direct"},
            }

    elif _state.mode == "cloud":
        async with httpx.AsyncClient(timeout=120.0) as c:
            headers = {"Authorization": f"Bearer {API_KEY}"}
            r = await c.post(f"{ELYSIUM_URL}/api/chat", json=req.model_dump(), headers=headers)
            return r.json()

    elif _state.mode == "ollama":
        async with httpx.AsyncClient(timeout=120.0) as c:
            payload = {
                "model": req.model or "llama3.2:3b",
                "messages": [{"role": "user", "content": req.message}],
                "stream": False,
            }
            r = await c.post(f"{OLLAMA_URL}/api/chat", json=payload)
            data = r.json()
            return {
                "response": data.get("message", {}).get("content", ""),
                "model_used": data.get("model", "ollama"),
                "metadata": {"elapsed_ms": 0, "effort_level": 1, "via": "ollama-direct"},
            }

    else:
        raise HTTPException(503, "No LLM backend available. Install Ollama or connect to Elysium.")


@app.post("/deploy")
async def deploy(target: str = "docker", service: str = "", config: dict = None):
    """Deploy via AitherComet (if Genesis available)."""
    if not _state.genesis:
        raise HTTPException(503, "Deployment requires Genesis. Start AitherOS or connect to cloud.")

    import httpx
    async with httpx.AsyncClient(timeout=60.0) as c:
        headers = {}
        if API_KEY:
            headers["Authorization"] = f"Bearer {API_KEY}"
        payload = {
            "service": service,
            "target": target,
            "config": config or {},
        }
        # Route through MeshCore/Comet
        r = await c.post(f"{GENESIS_URL}/deploy/deploy", json=payload, headers=headers)
        return r.json()


@app.get("/deploy/status")
async def deploy_status():
    """Get deployment status from Comet."""
    if not _state.genesis:
        return {"status": "disconnected", "message": "Genesis not available"}

    import httpx
    async with httpx.AsyncClient(timeout=10.0) as c:
        headers = {}
        if API_KEY:
            headers["Authorization"] = f"Bearer {API_KEY}"
        try:
            r = await c.get(f"{GENESIS_URL}/deploy/deployments", headers=headers)
            return r.json()
        except Exception:
            return {"status": "error", "deployments": []}


@app.post("/connect")
async def connect_to_cloud(api_key: str = "", email: str = ""):
    """Register this node with Elysium cloud."""
    from aithersdk.gateway import GatewayClient

    gw = GatewayClient(api_key=api_key or API_KEY)

    if email and not api_key:
        # Need to register first
        return {"error": "Use `aither connect` or provide api_key"}

    try:
        result = await gw.register_agent(
            name=f"node-{os.environ.get('COMPUTERNAME', 'local')}",
            capabilities=["chat", "code", "filesystem", "git"],
            description="AitherNode local gateway",
        )
        return {"status": "connected", "agent_id": result.get("agent_id", "")}
    except Exception as e:
        return {"status": "error", "error": str(e)}


# ── Workspace Sync Endpoints ──────────────────────────────────────


class AgentRoutingConfig(BaseModel):
    routing: Dict[str, str] = {}  # agent_name -> "local"|"cloud"|"auto"


class WorkspaceConfigUpdate(BaseModel):
    agent_routing: Optional[Dict[str, str]] = None
    inference_contribution: Optional[bool] = None


@app.get("/sync/status")
async def sync_status():
    """Get current workspace sync status."""
    sync = get_sync_client()
    return sync.get_status()


@app.post("/sync/register")
async def sync_register():
    """Force re-registration with the cloud platform."""
    sync = get_sync_client()
    result = await sync.register_endpoint()
    return result


@app.post("/sync/now")
async def sync_now():
    """Trigger an immediate workspace sync."""
    sync = get_sync_client()
    result = await sync.sync_workspace()
    return result


@app.get("/config")
async def get_config():
    """Get current workspace configuration including agent routing."""
    sync = get_sync_client()
    return {
        "workspace": {
            "tenant_id": sync.workspace.tenant_id,
            "workspace_id": sync.workspace.workspace_id,
            "workspace_name": sync.workspace.workspace_name,
            "tier": sync.workspace.tier,
            "agent_roster": sync.workspace.agent_roster,
            "agent_routing": sync.workspace.agent_routing,
            "inference_contribution": sync.workspace.inference_contribution,
            "settings": sync.workspace.settings,
        },
        "endpoint": {
            "node_id": sync.endpoint.node_id,
            "hostname": sync.endpoint.hostname,
            "gpu": sync.endpoint.gpu_name or "none",
            "gpu_vram_mb": sync.endpoint.gpu_vram_mb,
            "inference_ready": sync.endpoint.inference_ready,
            "available_models": sync.endpoint.available_models,
        },
    }


@app.put("/config")
async def update_config(update: WorkspaceConfigUpdate):
    """Update local workspace configuration and push to cloud.

    Changes are applied locally and synced to the cloud on next sync cycle.
    Use POST /sync/now to push immediately.
    """
    sync = get_sync_client()

    if update.agent_routing is not None:
        valid_modes = {"local", "cloud", "auto"}
        for agent, mode in update.agent_routing.items():
            if mode not in valid_modes:
                raise HTTPException(
                    400,
                    f"Invalid routing mode '{mode}' for agent '{agent}'. "
                    f"Must be one of: {', '.join(sorted(valid_modes))}",
                )
        sync.workspace.agent_routing = update.agent_routing

    if update.inference_contribution is not None:
        sync.workspace.inference_contribution = update.inference_contribution

    sync._save_local_state()
    return {"status": "updated", "config": sync.workspace.__dict__}


# ── License & Subscription ─────────────────────────────────────


@app.get("/license")
async def license_status():
    """Get current subscription/license status and entitlements."""
    lic = get_license_manager()
    return lic.to_dict()


@app.post("/license/validate")
async def license_validate():
    """Force re-validation of subscription against ACTA."""
    lic = get_license_manager()
    result = await lic.validate(force=True)
    return {**result, "entitlement": lic.to_dict()}


# ── Portal UI Proxy ────────────────────────────────────────────


PORTAL_URL = os.environ.get("AITHER_PORTAL_URL", "https://portal.aitherium.com")


@app.get("/")
async def portal_redirect():
    """Redirect browser to portal with auto-auth."""
    from fastapi.responses import HTMLResponse

    api_key = API_KEY or SYNC_API_KEY
    sync = get_sync_client()
    tenant_id = sync.workspace.tenant_id or ""

    # Serve a landing page that redirects to portal with auth context
    html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>AitherNode</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
               background: #0a0a0f; color: #e0e0e0; display: flex; align-items: center;
               justify-content: center; height: 100vh; margin: 0; }}
        .card {{ background: #13131a; border: 1px solid #2a2a3a; border-radius: 12px;
                 padding: 40px; max-width: 480px; text-align: center; }}
        h1 {{ color: #7c6bff; margin-bottom: 8px; }}
        .status {{ font-size: 14px; color: #888; margin-bottom: 24px; }}
        a.btn {{ display: inline-block; background: #7c6bff; color: white; padding: 12px 32px;
                 border-radius: 8px; text-decoration: none; font-weight: 600; margin: 8px; }}
        a.btn:hover {{ background: #6b5ce7; }}
        a.secondary {{ background: #2a2a3a; }}
        .info {{ font-size: 13px; color: #666; margin-top: 20px; }}
    </style>
</head>
<body>
    <div class="card">
        <h1>AitherNode</h1>
        <div class="status">
            Mode: {_state.mode} &bull;
            Plan: {get_license_manager().entitlement.resolved_plan} &bull;
            Node: {sync.endpoint.hostname or 'local'}
        </div>
        <a class="btn" href="{PORTAL_URL}?node=localhost:{NODE_PORT}&key={api_key[:8] + '...' if api_key else 'none'}"
           target="_blank">Open Portal Dashboard</a>
        <br>
        <a class="btn secondary" href="/status">API Status</a>
        <a class="btn secondary" href="/license">License</a>
        <a class="btn secondary" href="/config">Config</a>
        <div class="info">
            MCP endpoint: <code>http://localhost:{NODE_PORT}/sse</code><br>
            API docs: <a href="/docs" style="color:#7c6bff">/docs</a>
        </div>
    </div>
</body>
</html>"""
    return HTMLResponse(content=html)


@app.get("/endpoints")
async def list_fleet_endpoints():
    """List all endpoints in this workspace's fleet (proxied from cloud)."""
    import httpx as _httpx

    sync = get_sync_client()
    if not SYNC_API_KEY:
        return {"error": "No API key configured", "endpoints": []}

    from aithernode.sync import GATEWAY_URL

    try:
        async with _httpx.AsyncClient(timeout=10.0) as c:
            r = await c.get(
                f"{GATEWAY_URL}/v1/endpoints",
                headers={"Authorization": f"Bearer {SYNC_API_KEY}"},
            )
            if r.status_code == 200:
                return r.json()
            return {"error": f"HTTP {r.status_code}", "endpoints": []}
    except Exception as e:
        return {"error": str(e), "endpoints": []}
